clear;

t = [1:1500];

file1 = fopen('/Users/avrosh/Documents/Coursework/Project Studio/3rd arm/Avro/Fancy/motor1.txt');
file2 = fopen('/Users/avrosh/Documents/Coursework/Project Studio/3rd arm/Avro/Fancy/motor2.txt');
file3 = fopen('/Users/avrosh/Documents/Coursework/Project Studio/3rd arm/Avro/Fancy/motor3.txt');
M1 = fscanf(file1,'%f');
M2 = fscanf(file2,'%f');
M3 = fscanf(file3,'%f');

% file4 = fopen('/Users/avrosh/Documents/Coursework/Project Studio/3rd arm/Avro/Actions/motor1.txt');
% file5 = fopen('/Users/avrosh/Documents/Coursework/Project Studio/3rd arm/Avro/Actions/motor1.txt');
% file6 = fopen('/Users/avrosh/Documents/Coursework/Project Studio/3rd arm/Avro/Actions/motor1.txt');
% M4 = fscanf(file4,'%f');
% M5 = fscanf(file5,'%f');
% M6 = fscanf(file6,'%f');

min = 290;
max = 345;

t_cut = t(1,min:max);
M4 = M1(min:max,1);
M5 = M2(min:max,1);
M6 = M3(min:max,1);


figure; plot(t,M1,t,M2,t,M3);
figure; plot(t_cut,M4,t_cut,M5,t_cut,M6);